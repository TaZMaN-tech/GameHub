//
//  FavoritesModels.swift
//  GameHub
//
//  Created by Тадевос Курдоглян on 18.11.2025.
//

import Foundation

struct FavoriteGameViewModel {
    let title: String
    let subtitle: String
    let imageURL: URL?
}
