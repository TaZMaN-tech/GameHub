//
//  FavoriteGame+CoreDataClass.swift
//  GameHub
//
//  Created by Тадевос Курдоглян on 21.11.2025.
//
//

public import Foundation
public import CoreData

public typealias FavoriteGameCoreDataClassSet = NSSet

@objc(FavoriteGame)
public class FavoriteGame: NSManagedObject {

}
